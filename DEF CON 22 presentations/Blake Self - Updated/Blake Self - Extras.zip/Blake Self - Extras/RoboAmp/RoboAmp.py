#!/usr/bin/python
#
# RoboAmp v 1.00 (Public Defcon 22 Release)
# by rat@soldierx.com
#
# Copyright (c) 2013-2014 SOLDIERX.COM
# All rights reserved.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

from Adafruit_CharLCD import Adafruit_CharLCD
from googlevoice import Voice
import time
import subprocess
import cStringIO
import pycurl
import re
import os
import sys
import signal
import datetime
import getopt
import getpass

cmd = "ip addr show eth0 | grep inet | awk '{print $2}' | cut -d/ -f1"

def handler(signum, frame):
	print "[ROBOAMP] Signal handler called with signal", signum
	raise Exception("AlarmSignal")

def run_cmd(cmd):
	p = subprocess.Popen(cmd, shell=True, stdout=PIPE)
	output = p.communicate()[0]
	return output

def check_site(url, offlineString):
	try:
		signal.alarm(30) # set signal alarm for 30 seconds
		now = datetime.datetime.now()
		print "[ROBOAMP] Checking site %s - %s" % (url, str(now))
		referer = "http://www.soldierx.com"
		buf = cStringIO.StringIO()
		c = pycurl.Curl()
		c.setopt(c.WRITEFUNCTION, buf.write)
		c.setopt(pycurl.CONNECTTIMEOUT, 10)
		c.setopt(pycurl.TIMEOUT, 10)
		c.setopt(c.URL, url)
		c.setopt(pycurl.FOLLOWLOCATION, True)
		c.setopt(pycurl.MAXREDIRS, 5)
		c.setopt(pycurl.USERAGENT, 'RoboAmp')
		c.setopt(c.REFERER, referer)
		#c.setopt(c.PROXY, '127.0.0.1')
		#c.setopt(c.PROXYPORT, 9050)
		#c.setopt(c.PROXYTYPE, pycurl.PROXYTYPE_SOCKS5)
		c.setopt(pycurl.SSL_VERIFYPEER, 1)
		c.setopt(pycurl.SSL_VERIFYHOST, 2)
		#curl.setopt(pycurl.CAINFO, "/path/to/updated-certificate-chain.crt")
		c.setopt(pycurl.HTTPGET, 1)
		c.perform()
		data = buf.getvalue()
		buf.close()
		signal.alarm(0) # disable signal
		offline_matches=len(re.findall(offlineString,data))
		if offline_matches > 0:
			return -1 # site is offline
		else:
			return 0 # site is online
	except Exception, detail:
		signal.alarm(0) # disable signal
		print "[ROBOAMP] Error checking the site: %s" % (detail)
		return -1 # issue, say site is offline

def gvlogin(EMAIL, PASSWORD):
	global VOICE
	try:
		VOICE.login(EMAIL,PASSWORD)
	except Exception, detail:
		print "[ROBOAMP] Login failed: %s" % (detail)
		exit(0)

def gvlogout():
	global VOICE
	if(VERBOSE):
		print "[ROBOAMP] Logging out of google voice..."
	VOICE.logout()

def send_sms(EMAIL, PASSWORD, PHONE, Msg):
	try:
		gvlogin(EMAIL, PASSWORD)
		VOICE.send_sms(PHONE, Msg)
		gvlogout()
	except Exception, detail:
		print "[ROBOAMP] Error sending SMS message: %s" % (detail)
		return -1 # issue, say site is offline

# usage message for help and when there's an error
def usage():
	print "RoboAmp -d/-p -u url [ -s offlineString -p -l -g name@gmail.com -t timeout -v]"
	print "\t-d\t\t\tDeep check (check url content)"
	print "\t-p\t\t\tPing check (check network connectivity)"
	print "\t-u <url>\t\tURL of site to check"
	print "\t-s <offlineString>\tString to look for to verify site is offline"
	print "\t-l\t\t\tUse 16x2 LCD (Raspberry PI)"
	print "\t-g <gmailAddress>\tGmail address for google voice SMS notification"
	print "\t-t <seconds>\tSeconds to wait between checks (defaults to 60)"
	print "\t-v\t\t\tTurns on extra verbosity"
	print "Example Usage:"
	print "./RoboAmp -d -u https://www.soldierx.com/admin -s 'Site off-line' -g shinobi@gmail.com -t 120"

def main(argv=None):
	global VERBOSE, VOICE
	DEEP = PING = USE_LCD = USE_SMS = VERBOSE = False
	URL = OFFSTRING = EMAIL = PASSWORD = PHONE = ''
	TIMEOUT = 0 # timeout in seconds

	# collect command-line args
	try:
		opts, otherargs = getopt.getopt( sys.argv[1:], "hdplu:s:g:t:v", ["help", "deep", "ping", "lcd", "url=", "offlinestring=", "gmail=", "timeout=", "verbose"] )
		if len(sys.argv) < 2:
			print "[ROBOAMP] Not enough arguments."
			usage()
			sys.exit(1)
	except getopt.GetoptError:
		print "[ROBOAMP] Invalid option found."
		usage()
		sys.exit(1)

	# parse command-line options
	for o, a in opts:
		if o in ("-h", "--help"):
			usage()
			sys.exit(0)
		elif o in ("-d", "--deep"):
			DEEP = True
		elif o in ("-p", "--ping"):
			PING = True
		elif o in ("-u", "--url"):
			try:
				URL = a
				if (URL.count('/') > 2):
					hostname = re.search("http[s]?:\/\/(.+?)\/.*", URL).group(1)
				else:
					hostname = re.search("http[s]?:\/\/(.*)", URL).group(1)
			except:
				print "[ROBOAMP] URL seems to be invalid, make sure you include http[s]://"
				usage()
				sys.exit(2)
		elif o in ("-s", "--string"):
			try:
				OFFSTRING = a
			except:
				print "[ROBOAMP] Offline string seems to be invalid"
				usage()
				sys.exit(2)
		elif o in ("-l", "--lcd"):
			USE_LCD = True
		elif o in ("-g", "--gmail"):
			try:
				USE_SMS = True
				VOICE = Voice()
				EMAIL = a
				#PASSWORD = raw_input("\tEnter your gmail password: ")
				PASSWORD = getpass.getpass("\tEnter your gmail password: ")
				PHONE = raw_input("\tEnter phone number to SMS (e.g. 8177511243): ")
			except:
				print "[ROBOAMP] Gmail information seems to be invalid"
				usage()
				sys.exit(2)
		elif o in ("-t", "--timeout"):
			try:
				TIMEOUT = int(a)
			except:
				print "[ROBOAMP] Timeout is invalid, please use an integer to specify timeout in seconds"
				usage()
				sys.exit(2)
		elif o in ("-v", "--verbose"):
			VERBOSE = True
			print "[ROBOAMP] Verbose mode enabled"

	# Error check options
	if(URL==''):
		print "[ROBOAMP] No URL specified, cannot continue"
		usage()
		sys.exit(2)
	if(DEEP and PING):
		print "[ROBOAMP] You can only do Deep check OR Ping Check, not both"
		usage()
		sys.exit(2)
	if(DEEP==False and PING==False):
		if(VERBOSE):
			print "[ROBOAMP] Neither Deep check OR Ping Check specified, defaulting to Ping Check..."
		PING = True
	if(DEEP and OFFSTRING==''):
		if(VERBOSE):
			print "[ROBOAMP] No offline string specified, defaulting to 'Site off-line'..."
		OFFSTRING = "Site off-line"
	if(USE_SMS and (EMAIL=='' or PASSWORD=='' or PHONE=='')):
		if(VERBOSE):
			print "[ROBOAMP] Incomplete google voice information entered, turning off SMS..."
		USE_SMS = False
	if(TIMEOUT <=0):
		if(VERBOSE):
			print "[ROBOAMP] Timeout must be greater than 0, defaulting to 60 seconds..." 
		TIMEOUT = 60

	# we get signal :-P
	signal.signal(signal.SIGALRM, handler)

	if(VERBOSE):
		print "[ROBOAMP] hostname set to %s" % (hostname)
				
	if(USE_LCD):
		if(VERBOSE):
			print "[ROBOAMP] Initializing LCD..."
		lcd = Adafruit_CharLCD() # you can substitute this with your own LCD code
		lcd.begin(16,1)

	if(USE_SMS):
		sms = 0

	while True: # endless loop
		if(USE_LCD):
			lcd.clear()
			lcd.message("Testing ...")
			time.sleep(.5)
			
		if(PING):
			response = os.system("ping -c 1 " + hostname)
		if(DEEP):
			response = check_site(URL, OFFSTRING)
		# response == 0 means site is up
		if response == 0:
			if(USE_LCD):
				lcd.clear()
				lcd.message(hostname + "\n  -= is UP =-")
			print "[ROBOAMP] %s is UP" % (hostname)
			if(USE_SMS):
				if sms > 0:
					send_sms(EMAIL, PASSWORD, PHONE, hostname + " is back up!")
				sms = 0
		else:
			if(USE_LCD):
				lcd.clear()
				lcd.message(hostname + "\n  -= is DOWN =-")
			print "[ROBOAMP] %s is DOWN" % (hostname)
			if(USE_SMS):
				sms = sms + 1
				if sms <= 1:
					send_sms(EMAIL, PASSWORD, PHONE, hostname + " is DOWN!")
		time.sleep(TIMEOUT) #
	print "f-f-f-f-f-frozen" # should never get here, lol

if __name__ == "__main__":
	sys.exit(main())
