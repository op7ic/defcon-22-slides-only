#Viproy - VoIP Penetration Testing Kit
VoIP Services Testing Modules for Metasploit Framework

#Homepage of Project
http://viproy.com<br>

#Preparing Test Network
VulnVOIP is vulnerable SIP server, you can use it for tests<br>
VulnVOIP : http://www.rebootuser.com/?cat=371<br>

#Installation
Copy "lib" and "modules" folders' content to Metasploit Root Directory.<br>
Mixins.rb File (lib/msf/core/auxiliary/mixins.rb) Should Contain This Line<br>
require 'msf/core/auxiliary/sip'<br>

#Sample Usage Video (Video)
http://www.youtube.com/watch?v=1vDTujNVKGM

#Hacking Trust Relationships of SIP/NGN Gateways (Video)
http://www.youtube.com/watch?v=BVJq2yrHYhI

#Hacking Trust Relationships Between SIP Gateways (PDF)
http://viproy.com/files/siptrust.pdf