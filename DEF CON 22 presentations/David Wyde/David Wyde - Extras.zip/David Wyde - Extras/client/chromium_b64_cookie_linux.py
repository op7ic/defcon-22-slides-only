"""
Base64-encode an encrypted cookie value from Chromium's cookie database.

Note: you'll probably need to change the `db_path` variable.
"""

import base64
import sqlite3


db_path = '/home/david/.config/google-chrome-unstable/Default/Cookies'
con = sqlite3.connect(db_path)
cursor = con.cursor()
cursor.execute('SELECT encrypted_value FROM cookies WHERE name="GX"'
			   'AND host_key=".mail.google.com"')
encrypted_value = str(cursor.fetchone()[0])
print base64.b64encode(encrypted_value)
