#ifndef WIN_HTTP_H
#define WIN_HTTP_H

void http_send_data(std::string post_data);

#endif
