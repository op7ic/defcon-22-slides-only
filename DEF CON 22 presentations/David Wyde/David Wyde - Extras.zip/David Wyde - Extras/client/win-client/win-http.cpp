// The following code was adapted from
// http://msdn.microsoft.com/en-us/library/aa384270(v=vs.85).aspx
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <windows.h>
#include <winhttp.h>

#define SERVER_HOST L"192.168.1.100"
#define SERVER_PORT 8000
#define SERVER_PATH L"/cookies/"


void http_send_data(std::string post_data) {
    
    printf("%s\n", post_data.c_str());
  
    DWORD dwSize = 0,
          dwDownloaded = 0,
          dwBytesWritten = 0;
    LPSTR pszOutBuffer;
    BOOL  bResults = FALSE;
    HINTERNET  hSession = NULL, 
               hConnect = NULL,
               hRequest = NULL;

    // Use WinHttpOpen to obtain a session handle.
    hSession = WinHttpOpen(L"Snickerdoodle/1.0",  
                           WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
                           WINHTTP_NO_PROXY_NAME, 
                           WINHTTP_NO_PROXY_BYPASS,
                           0);

    // Specify an HTTP server.
    if (hSession) {
        hConnect = WinHttpConnect(hSession,
                                  SERVER_HOST,
                                  SERVER_PORT,
                                  0);
    }

    // Create an HTTP request handle.
    if (hConnect) {
        hRequest = WinHttpOpenRequest(hConnect,
                                      L"POST",
                                      SERVER_PATH,
                                      NULL,
                                      WINHTTP_NO_REFERER, 
                                      WINHTTP_DEFAULT_ACCEPT_TYPES, 
                                      NULL);
    }

    // Send a request.
    if (hRequest) {
        bResults = WinHttpSendRequest(hRequest,
                                      L"Content-Type: application/x-www-form-urlencoded",
                                      -1,
                                      (LPSTR) post_data.c_str(),
                                      post_data.length(), 
                                      post_data.length(),
                                      0);
    }

    // End the request.
    if (bResults) {
        bResults = WinHttpReceiveResponse( hRequest, NULL );
    }

    // Keep checking for data until there is nothing left.
    if (bResults) {
        do {
            // Check for available data.
            dwSize = 0;
            if (!WinHttpQueryDataAvailable(hRequest, &dwSize)) {
                printf( "Error %u in WinHttpQueryDataAvailable.\n",
                GetLastError( ) );
            }
      
            // Allocate space for the buffer.
            pszOutBuffer = new char[dwSize + 1];
            if( !pszOutBuffer ) {
                printf( "Out of memory\n" );
                dwSize=0;
            } else {
                // Read the data.
                ZeroMemory(pszOutBuffer, dwSize + 1);

                if (!WinHttpReadData(hRequest,
                                     (LPVOID)pszOutBuffer, 
                                     dwSize,
                                     &dwDownloaded)) {
                    printf("Error %u in WinHttpReadData.\n",
                           GetLastError());
                }
                else {
                    printf("%s", pszOutBuffer);
                }

                // Free the memory allocated to the buffer.
                delete [] pszOutBuffer;
            }
        } while(dwSize > 0);
    }

    // Report any errors.
    if (!bResults) {
        printf("Error %d has occurred.\n", GetLastError());
    }

    // Close any open handles.
    if (hRequest) {
        WinHttpCloseHandle(hRequest);
    }
    if (hConnect) {
        WinHttpCloseHandle(hConnect);
    }
    if (hSession) {
        WinHttpCloseHandle(hSession);
    }
}
