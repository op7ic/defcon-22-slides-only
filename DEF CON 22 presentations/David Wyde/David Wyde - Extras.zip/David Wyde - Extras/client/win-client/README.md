# Chromium on Windows: Cookie Thief

This code reads Gmail authentication cookies (named `GX` and `SID`)
from a user's Chromium cookie database, then POSTs them via HTTPS to
a server running with a hard-coded address, port, and path.

The SQLite 3 amalgamation files are required (sqlite3.c/sqlite3.h),
but were omitted to save space. I used version 3.8.3.1.

The server info is hard-coded near the top of `win-http.h`.
I tested it with the Django server that is part of this project.
