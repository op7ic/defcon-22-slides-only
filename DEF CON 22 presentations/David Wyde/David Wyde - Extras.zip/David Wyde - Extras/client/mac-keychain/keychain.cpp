//
// Read Chromium's encryption password from Mac's system keychain.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <Security/Security.h>

const char *service = "Chrome Safe Storage";
const char *account = "Chrome";
char *password;
unsigned int password_len = 0;

int main(int argc, char *argv[])
{


    SecKeychainFindGenericPassword(
        NULL,
        strlen(service),
        service,
        strlen(account),
        account,
        &password_len,
        (void **) &password,
        NULL
    );

    std::cout << password_len << std::endl;
    printf("%.*s\n", password_len, password);

    return 0;
}

