# Cookie-Collecting Server

This is a server that receives cookies taken from HTTP clients.
It is a proof-of-concept for my DEF CON 22 talk.

To set up the server, follow standard Django practice:

1. If you don't have Django, `pip install -r requirements.txt`
1. `python manage.py syncdb`
1. Follow the prompts to create an admin user
1. `python manage.py runserver 0.0.0.0:8000` to listen for cookies

Once a client has sent cookies, browse to
[http://localhost:8000/admin/cookies/cookie/](http://localhost:8000/admin/cookies/cookie/). Check the desired cookies, then select
"Use cookies in a browser" from the `Action` dropdown,
and press the `Go` button.

Please note that there is a race condition with the creation
of the temporary cookie database when launching a browser session.
If authentication doesn't immediately work, wait for a minute
and then reload the page.

The Windows cookie-reading code expects this server to be listening
on port 8000, on a hard-coded IP.
