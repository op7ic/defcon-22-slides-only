from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

from cookies.forms import CookieForm


@csrf_exempt
def process_cookie(request):
    form = CookieForm(request.POST)
    if form.is_valid():
        form.save()
        return HttpResponse('Thanks!')
    else:
        return HttpResponse('No Thanks!', status=400)
