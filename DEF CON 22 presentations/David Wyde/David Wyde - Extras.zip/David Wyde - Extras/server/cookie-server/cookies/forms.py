from django.forms import ModelForm

from cookies.models import Cookie


class CookieForm(ModelForm):
    class Meta:
        model = Cookie

