"""
Open a Chromium browser session, populated with cookies.
"""
import datetime
import os.path
import shutil
import sqlite3
import subprocess
import tempfile
import time


# A default profile.
EMPTY_PROFILE = os.path.join(os.path.dirname(__file__),
                             '..',
                             'empty-profile')

# Timestamp diff until cookie expiration.
EXPIRES_IN = (10 ** 7) * 60 * 60 * 24 * 365

# A fallback timestamp if no values are in the cookies database;
# e.g., 13039343026883023.
DEFAULT_TIMESTAMP = int(time.time()) * (10 ** 7)


def launch_browser(cookies):
    temp_dir = tempfile.mkdtemp()
    shutil.rmtree(temp_dir)
    shutil.copytree(EMPTY_PROFILE, temp_dir, symlinks=True)
    db_path = os.path.join(temp_dir, 'Default', 'Cookies')

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    for cookie in cookies:
        for name_value_pair in cookie.value.strip(';').split(';'):
            cursor.execute('SELECT MAX(creation_utc) FROM cookies')
            db_timestamp = cursor.fetchone()[0]
            if db_timestamp:
                timestamp = int(db_timestamp) + 1
            else:
                timestamp = DEFAULT_TIMESTAMP
            
            name, value = name_value_pair.split('=', 1)            
            params = (timestamp, cookie.host, name, value, '/',
                      timestamp + EXPIRES_IN, 1, 1, timestamp, 1, 1, 1)
            cursor.execute('INSERT INTO cookies VALUES (?, ?, ?, ?, ?, '
                           '?, ?, ?, ?, ?, ?, ?)', params)
            
    conn.commit()
    cursor.close()
    conn.close()

    urls = [cookie.host.strip('.') for cookie in cookies]
    p = subprocess.Popen(['chromium-browser',
                          '--user-data-dir=%s' % temp_dir]
                          + urls)
    p.wait()
    shutil.rmtree(temp_dir)
