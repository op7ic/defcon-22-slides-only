from django.conf.urls import patterns, url


urlpatterns = patterns('cookies.views',
    url(r'^$', 'process_cookie', name='process_cookie'),
)
