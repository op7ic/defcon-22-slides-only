from django.db import models


class Cookie(models.Model):
    
    # TO-DO: check cookie RFC for max lengths (4096 characters?)
    # http://browsercookielimits.x64.me/ says max is 5117 characters.
    
    host = models.CharField(max_length=256)
    
    value = models.TextField()

    def __unicode__(self):
        """ Display  the names of cookies, but not the values. """
        pairs = self.value.strip(';').split(';')
        keys = [pair.split('=', 1)[0] for pair in pairs]
        return u'%s :: %s' % (self.host, '; '.join(keys))
