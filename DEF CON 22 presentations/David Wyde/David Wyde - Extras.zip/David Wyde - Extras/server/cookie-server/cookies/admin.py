from django.contrib import admin

from cookies.browser import launch_browser
from cookies.models import Cookie


class CookieAdmin(admin.ModelAdmin):
    
    actions = ('open_in_browser',)

    def open_in_browser(self, request, queryset):
        launch_browser(queryset)
    open_in_browser.short_description = 'Use cookies in a browser'

admin.site.register(Cookie, CookieAdmin)
