//
// Read, and decrypt, encrypted cookie values from Chromium on Linux.
// The database path is hard-coded, and the cookies are for Gmail.
//

#include <iostream>
#include <sqlite3.h>

#include "decrypt_cookie.h"

// Path to a Chromium cookie database.
#define COOKIE_DB_PATH "/home/david/.config/chromium/Default/Cookies"

int main()
{
    sqlite3 *db;
    sqlite3_stmt *res;
    const char *tail;
    const void *blob;
    unsigned int len;
    std::string encrypted_value;
    std::string plaintext;
    int error = sqlite3_open(COOKIE_DB_PATH,
                             &db);
    if (error) {
        std::cout << "Can't open database: " << sqlite3_errmsg(db) << std::endl;
    } else {
        std::cout << "Opened DB." << std::endl;
        error = sqlite3_prepare(db,
        "SELECT name, encrypted_value FROM cookies"
        " WHERE name IN ('GX', 'SID') AND host_key LIKE '%%.google.com'"
        " ORDER BY name",
        1000, &res, &tail);

        if (error != SQLITE_OK) {
            std::cout << "We did not get any data!" << std::endl;
        } else {
            while (sqlite3_step(res) == SQLITE_ROW) {
                std::cout << "Cookie: " << sqlite3_column_text(res, 0)
                          << std::endl;
                
                blob = sqlite3_column_blob(res, 1);
                len = sqlite3_column_bytes(res, 1);
                encrypted_value.resize(len);
                encrypted_value.assign(reinterpret_cast<const char*>(blob), len);
                std::cout << "Blob prefix: " << encrypted_value.substr(0, 3) << std::endl;
                // Print encrypted value (binary data).
                std::cout << encrypted_value.substr(3) << std::endl;
                std::cout << "Blob length: " << sqlite3_column_bytes(res, 1) << std::endl;
                decrypt(encrypted_value.substr(3));
            }
        }
        sqlite3_finalize(res);
    }
    
    sqlite3_close(db);
}
