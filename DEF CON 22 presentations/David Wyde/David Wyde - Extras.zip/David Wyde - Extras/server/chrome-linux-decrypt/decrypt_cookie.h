#ifndef DECRYPT_COOKIE_H
#define DECRYPT_COOKIE_H

void decrypt(std::string input);
 
#endif /* DECRYPT_COOKIE_H */
