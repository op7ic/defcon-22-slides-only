# Chromium on Linux: Cookie Reader

This directory contains code to read Chromium cookies that were encrypted
on Linux. For more details, see the Makefile and source code.

The `db_reader` target reads, decrypts, and prints cookies from a
hard-coded path to a Chromium cookie SQLite database.

The `base64_reader` target base64-decodes, decrypts, and prints
a cookie value that Chromium has encrypted on Linux.

The `all` target makes both `db_reader` and `base64_reader`.

I built Chromium as multiple shared libraries, following 
[http://www.chromium.org/developers/how-tos/component-build](http://www.chromium.org/developers/how-tos/component-build) 
and [http://code.google.com/p/chromium/wiki/LinuxBuildInstructions](http://code.google.com/p/chromium/wiki/LinuxBuildInstructions).
