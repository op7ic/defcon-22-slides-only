//
// Decrypt a base64-encoded Chromium Linux cookie.
// This value should be pulled from the "encrypted_value" column
// of Chromium's SQLite cookie database.
//
// Fails if the supplied command-line argument is not valid.
//

#include <iostream>

// Chromium includes
#include <base/base64.h>

#include "decrypt_cookie.h"

int main(int argc, char *argv[])
{
    std::string encrypted_cookie;

    if (argc == 2) {
        base::Base64Decode(argv[1], &encrypted_cookie);
        decrypt(encrypted_cookie.substr(3));
    } else {
        std::cerr << "Please supply a base64-encoded cookie as "
                  << "the sole command line argument." << std::endl;
    }

}
