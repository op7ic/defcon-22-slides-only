//
// Helper code to decrypt a Chromium cookie that has been
// encrypted on Linux with NSS.
//
// The encryption key is currently hard-coded in Chromium's source code.
// I couldn't figure out how to access their OSCrypt::decrypt() call,
// since it's not exported by the library, so I just copied the
// key and code here.
//

#include <iostream>

// Chromium includes
#include <base/memory/scoped_ptr.h>
#include <components/os_crypt/os_crypt.h>
#include <crypto/encryptor.h>
#include <crypto/symmetric_key.h>

void decrypt(std::string input)
{
    std::string result;
    crypto::Encryptor encryptor;
    
    // Create an encryption key from our password and salt.
    scoped_ptr<crypto::SymmetricKey> encryption_key(
                crypto::SymmetricKey::DeriveKeyFromPassword(
                        crypto::SymmetricKey::AES,
                        "peanuts",
                        "saltysalt",
                        1,
                        128));
                        
    std::string iv(16, ' ');
    encryptor.Init(encryption_key.get(), crypto::Encryptor::CBC, iv);
    encryptor.Decrypt(input, &result);
    std::cout << result << std::endl;
}

