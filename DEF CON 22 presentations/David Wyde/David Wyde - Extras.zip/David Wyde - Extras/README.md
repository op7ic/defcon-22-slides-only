# David Wyde's DEF CON 22 Materials

This is the code for David Wyde's DEF CON 22 talk,
*Client-Side HTTP Cookie Security: Attack and Defense*.

The `client` directory contains code that might be used to take
cookies from a compromised machine.

The `server` directory contains a cookie-collecting server,
and code to decrypt Chromium's Linux cookies.

Enjoy!

*-David Wyde, 2014-07-14*
