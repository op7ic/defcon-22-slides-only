// ProcDetect.cpp : shane.macaulay@ioactive.com (Copyright(c) All rights reserved)
// Scan for page tables in a given input file using PFN FTW trick-trick
// I've changed some comments to make it margionally confusing to read this before 
// reading my slides or going to the talk !!!! 
// process hiding is dead!!!
// DEAD!
// D #<-- fense
//
// Funidmentally we have a very powerful 1 liner here that can be used for any given 4KB+ input
// Detect physical processes on the network snort signature! :)
// 
// Get integrity checking with The Memory Cruncher https://blockwatch.ioactive.com/ 
// By the time of DC22 I hope to have intergrated this functionality, however if you want
// to dump a detected process with this version of procdetect use ironpython & SO.Rtl to declare it in python.
// The benifit of using the BlockWatch library's to dump is that dumping is automatically delocated (makes disk byte-compare possiable)
//
// option 1 likes to know the full size of input with a very low amount of bits an attacker may attack
// option 2 makes use of more standard looking entries, may have attacks against it, 
// however it is good detection scanning blocks where physical memory limit not known

// 
// Also we try to detect/handle headers automagically (i.e. we do not hardcode info for DMP/vmem/other uncompressed memory format)
// this has lead us to a bit of state that is likely needless if forinstance support
// for a raw memory dump or other known DUMP header format's
//

#include "stdafx.h"
bool setDiff = false;
#define MAP_SIZE (1024*1024*64)

int IsPower(unsigned n)
{
	return n && (!(n & (n - 1)));
}

int PageTableScan(int mode, _TCHAR *file)
{
	int rv = 0;
	ULONGLONG FirstDiff = 0;

	HANDLE hFile = CreateFile(file, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_DELETE, 0, OPEN_EXISTING, 0, 0);
	if (hFile == INVALID_HANDLE_VALUE)
		return NULL;

	LARGE_INTEGER FileSize;
	unsigned long long CurrWindowBase = 0;

	GetFileSizeEx(hFile, &FileSize);

	HANDLE hMapping = CreateFileMapping(hFile, 0, PAGE_READONLY, 0, 0, NULL);
	if (hMapping == NULL)
	{
		CloseHandle(hFile);
		return NULL;
	}

	unsigned long long* lpMapping = (unsigned long long*) MapViewOfFile(hMapping, FILE_MAP_READ, 0, 0, MAP_SIZE); 
	if (lpMapping == NULL)
	{
		CloseHandle(hFile);
		CloseHandle(hMapping);
		return NULL;
	}
	unsigned long long WinLimit = (MAP_SIZE / 8);
	unsigned long long mapSize = MAP_SIZE;
	
	while (CurrWindowBase < FileSize.QuadPart)
	{
		// scan every page from lpMapping to lpMapping+MAP_SIZE
		for (unsigned long long i = 0; i < WinLimit; i += 512)
		{
			// first entry of table should not be null and end in 0x867 (or 0x67)
			// lower bits 0x867 configured
			if (lpMapping[i] != 0)
			{
				// we can reduce this further likely
				if (mode == 1 && (lpMapping[i] & 3) != 3)
					continue;
				if (mode == 2 && (lpMapping[i] & 0xfdf) != 0x847) 
					continue;

				// magic bits should be at index 0xf68/8 == 0x1ed
				ULONGLONG selfMap = lpMapping[i + 0x1ED];

				// if we can find a possiable map, extract current PFN
				ULONGLONG low12Bits = selfMap & 3; // 3 instead of 7 is user space 
				if (selfMap != 0 && (low12Bits == 3 || low12Bits == 1)) // probably worse than minimum (using this check you can observe diff skew to eliminate detected entries)
				//if (selfMap != 0 && (low12Bits == 0x63 || low12Bits == 0x67) )// mandated
				{
					ULONGLONG offset = CurrWindowBase + (i * 8);
					MMPTE_64 selfPTE;
					selfPTE.u.Long.QuadPart = selfMap;
					ULONGLONG shifted = (selfPTE.u.Flush.PageFrameNumber << PAGE_SHIFT);
					ULONGLONG diff = offset > shifted ? offset - shifted : shifted - offset;

					//this helps handle some header (DMP or something)
					// add a few extra checks here to ensure first diff is found well
					// it's so low in PFN there's not a lot of bits here yet
					if (!setDiff && diff < FileSize.QuadPart && (offset > shifted ? (diff + shifted == offset) : (diff + offset == shifted)) && low12Bits == 3)
					{
						FirstDiff = diff;
						setDiff = true;
					}

					// monitoring changes in diff allows us to qualify more detection based on expected memory run layout 
					// not including it here as using diff in this way would limit the ability to scan into VM guests's memory
					// from a host dump
					// e.g. diff would typically be congruant to the range of PFN 

					// selfPTE.u.Flush.PageFrameNumber should be lower than a known physical maximum amount of memory available
					// can be used to augment check if earlier flag checks fail or are removed
					// 
					// none of these are typically set reserved0 is set !! doubel check this! ;)
					if (mode == 2 &&
						(
						selfPTE.u.Flush.LargePage ||
						selfPTE.u.Flush.Prototype ||
						selfPTE.u.Flush.SoftwareWsIndex ||
						selfPTE.u.Flush.reserved1)
						)
						;
					else if (mode == 1 &&
						((diff - FirstDiff) != 0 && !IsPower(diff - FirstDiff)) || // may invalidate host->vm introspection 
						//!selfPTE.u.Flush.Dirty ||  // we can add additional checks
						// add these back in if scanning where PFN zero bits not known
						// should we be shifted + diff or does that compromise the check too much
						shifted > (FileSize.QuadPart + diff) ||  // this check not avail if scanning extents allocated zones or network packets.
						shifted == 0)
					{
						;
						// uncomment this to see what was tossed out
						//printf("skipping disqualified Directory Base Register Value = [%llx]  File Offset = [%llx], Diff = [%llx]\n", selfPTE.u.Flush.PageFrameNumber << PAGE_SHIFT, offset, diff);
					}
					else 
						// bittest mode did not disqualify us
					{
						printf("Possible Directory Base Register Value = [%llx]  File Offset = [%llx], Diff = [%llx]\n", selfPTE.u.Flush.PageFrameNumber << PAGE_SHIFT, offset, diff);
						rv++;
						// if were here w/o first probably in a raw memory dump
						if(!setDiff)
						{
							FirstDiff = diff;
							setDiff = true;
						}
					}
				}
			}
		}

		CurrWindowBase += MAP_SIZE;
		if (CurrWindowBase + MAP_SIZE > FileSize.QuadPart)
		{
			mapSize = FileSize.QuadPart - CurrWindowBase;
			WinLimit = mapSize / 8;
		}
		if (CurrWindowBase > FileSize.QuadPart)
			break;
		lpMapping = (unsigned long long*) MapViewOfFile(hMapping, FILE_MAP_READ, CurrWindowBase >> 32, CurrWindowBase & 0xffffffff, mapSize);
		if (!lpMapping)
			break;
	}
	printf("end map scan\n");
	return rv;
}


int _tmain(int argc, _TCHAR* argv[])
{
	int mode = 1;
	if(argc < 1)
	{
		printf("supply file name of memory dump/snapshot for AMD64 OS, Windows currently supported\n");
		printf("FYI: Windows PID 0,4 may be sharing a common table so process count is higher++.\n");
		return -1;
	}

	if (argc > 3)
	{
		printf("ProcDetect [1|2] filename\n");
		printf("\toption 1 is default\n");
	}
	_TCHAR *filename = argv[argc - 1];
	if (argc == 3)
		mode = wcstoul(argv[argc - 2], NULL, 10);
	if (mode != 2)
		mode = 1;
	wprintf(L"Starting mode %d scan of file %s\n", mode, filename);
	int count = PageTableScan(mode, filename);
	printf("detected process page tables = %d\n", count);
	if (count < 8) // some random amount
		printf("count is low, are you sure this is a full memory dump for an AMD64 build of Windows?");
	return 0;
}

