// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>



#include <Windows.h>


#define PAGE_SHIFT 12

// Update this struct based off of (e.g. in kd) "dt -r nt!_MMPTE"  (or not)
// for our purposes were need a valid bit so that establishes HARDWARE def
// 

typedef struct _MMPTE_SOFTWARE_64 {
	ULONGLONG Valid : 1;
	ULONGLONG PageFileLow : 4;
	ULONGLONG Protection : 5;
	ULONGLONG Prototype : 1;
	ULONGLONG Transition : 1;
	ULONGLONG UsedPageTableEntries : 10;
	ULONGLONG InStore : 1;
	ULONGLONG Reserved : 9;
	ULONGLONG PageFileHigh : 32;
} MMPTE_SOFTWARE_64;

typedef struct _MMPTE_TRANSITION_64 {
	ULONGLONG Valid : 1;
	ULONGLONG Write : 1;
	ULONGLONG Owner : 1;
	ULONGLONG WriteThrough : 1;
	ULONGLONG CacheDisable : 1;
	ULONGLONG Protection : 5;
	ULONGLONG Prototype : 1;
	ULONGLONG Transition : 1;
	ULONGLONG PageFrameNumber : 36;
	ULONGLONG Unused : 16;
} MMPTE_TRANSITION_64;

typedef struct _MMPTE_PROTOTYPE_64 {
	ULONGLONG Valid : 1;
	ULONGLONG Unused0 : 7;
	ULONGLONG ReadOnly : 1;
	ULONGLONG Unused1 : 1;
	ULONGLONG Prototype : 1;
	ULONGLONG Protection : 5;
	ULONGLONG ProtoAddress : 48;
} MMPTE_PROTOTYPE_64;

typedef struct _MMPTE_HARDWARE_64 {
	ULONGLONG Valid : 1;
	ULONGLONG Dirty1 : 1;
	ULONGLONG Owner : 1;
	ULONGLONG WriteThrough : 1;
	ULONGLONG CacheDisable : 1;
	ULONGLONG Accessed : 1;
	ULONGLONG Dirty : 1;
	ULONGLONG LargePage : 1;
	ULONGLONG Global : 1;
	ULONGLONG CopyOnWrite : 1;
	ULONGLONG Unused : 1;
	ULONGLONG Write : 1;
	ULONGLONG PageFrameNumber : 36;
	ULONGLONG reserved1 : 4;
	ULONGLONG SoftwareWsIndex : 11;
	ULONGLONG NoExecute : 1;
} MMPTE_HARDWARE_64, *PMMPTE_HARDWARE_64;

typedef struct _HARDWARE_PTE {
	ULONGLONG Valid : 1;
	ULONGLONG Write : 1;
	ULONGLONG Owner : 1;
	ULONGLONG WriteThrough : 1;
	ULONGLONG CacheDisable : 1;
	ULONGLONG Accessed : 1;
	ULONGLONG Dirty : 1;
	ULONGLONG LargePage : 1;
	ULONGLONG Global : 1;
	ULONGLONG CopyOnWrite : 1;
	ULONGLONG Prototype : 1;
	ULONGLONG reserved0 : 1;
	ULONGLONG PageFrameNumber : 36;
	ULONGLONG reserved1 : 4;
	ULONGLONG SoftwareWsIndex : 11;
	ULONGLONG NoExecute : 1;
} HARDWARE_PTE, *PHARDWARE_PTE;

typedef struct _MMPTE_64 {
	union  {
		ULARGE_INTEGER Long; // needed
		HARDWARE_PTE Flush; // needed
		// anything else is just fyi for this code purposes
		// also some of the names,reserved change across NT versions 
		MMPTE_HARDWARE_64 Hard; // pretty confusing to have HARDWARE_PTE && MMPTE_HARDWARE :)
		MMPTE_PROTOTYPE_64 Proto;
		MMPTE_SOFTWARE_64 Soft;
		MMPTE_TRANSITION_64 Trans;
	} u;
} MMPTE_64, *PMMPTE_64;